import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import { AppSyncEventsClient, useChannel } from '../lib/main'
import * as Auth from 'aws-amplify/auth'

const client = new AppSyncEventsClient(import.meta.env.VITE_HTTP_ENDPOINT, {
  // apiKey: import.meta.env.VITE_API_KEY,
  authorization: async () => {
    const session = await Auth.fetchAuthSession()
    return session.tokens?.idToken?.toString() ?? 'n/a'
  },
  // debug: true,
})
function App() {
  const [count, setCount] = useState(0)
  const stuff = useChannel(client, '/default/*', (data) => console.log(data))
  const { isReady, isError, channel, error } = useChannel(client, '/default/test')
  function handleclick() {
    channel?.publish("I'm the captain!")
  }

  // console.log('cactus:', isReady, isError, channel, error)
  console.log(stuff.isReady, stuff.isError, stuff.channel, stuff.error)

  return (
    <>
      <div>
        {/* biome-ignore lint/a11y/noBlankTarget: <explanation> */}
        <a href="https://vite.dev" target="_blank">
          <img src={viteLogo} className="logo" alt="Vite logo" />
        </a>
        {/* biome-ignore lint/a11y/noBlankTarget: <explanation> */}
        <a href="https://react.dev" target="_blank">
          <img src={reactLogo} className="logo react" alt="React logo" />
        </a>
      </div>
      <h1>Vite + React</h1>
      <div className="card">
        {/* biome-ignore lint/a11y/useButtonType: <explanation> */}
        <button onClick={() => setCount((count) => count + 1)}>count is {count}</button>

        {/* biome-ignore lint/a11y/useButtonType: <explanation> */}
        <button onClick={() => handleclick()}>Publish</button>
        <p>
          Edit <code>src/App.tsx</code> and save to test HMR
        </p>
      </div>
      <p className="read-the-docs">Click on the Vite and React logos to learn more</p>
    </>
  )
}

export default App
