# CLAUDE.md - Library Development Guidelines

## Build Commands
- `npm run dev` - Start development server
- `npm run build` - Build library for production
- `npm run lint` - Run ESLint
- `npm run format` - Format code with Biome
- `npx @biomejs/biome check --apply .` - Lint and format with Biome
- `npm run preview` - Preview library in test app

## Library Guidelines
- Export all public API from main.ts
- Keep backwards compatibility in mind
- Follow semver for versioning
- Include TypeScript type definitions
- Document all public APIs

## Code Style Guidelines

### TypeScript
- Strict mode enabled
- Define explicit types for function parameters and returns
- Follow ES2020 features, avoid older syntax
- No unused variables or parameters
- Use of 'any' is allowed in lib folder for flexibility

### Imports/Formatting
- Use ES modules (type: "module")
- Auto-organize imports with Biome
- Use single quotes for JavaScript, double quotes for JSX
- Semicolons: as needed
- Line width: 100 characters
- Space indentation

### Naming Conventions
- React components: PascalCase
- Functions/variables: camelCase
- Constants: UPPER_SNAKE_CASE
- Files: *.tsx for components, *.ts for utilities

### Error Handling
- Use explicit error types
- Handle async errors with try/catch
- Provide useful error messages to users

### React Best Practices
- Minimize external dependencies
- Ensure components are tree-shakeable
- Proper cleanup in useEffect hooks